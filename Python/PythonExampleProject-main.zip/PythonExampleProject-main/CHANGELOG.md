# Change Log

## 0.1.0

Released on October 29, 2022.

### Added

* First version of the project
    - Tests
    - first functions
    - Markdown files
    - etc...
