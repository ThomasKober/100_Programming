def hello():
    return 2 + 2
