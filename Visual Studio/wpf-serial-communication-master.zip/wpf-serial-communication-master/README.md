# wpf-serial-communication
C# WPF Serial Port Writing/Reading data
