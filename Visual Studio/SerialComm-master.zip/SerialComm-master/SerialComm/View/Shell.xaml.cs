﻿using SerialComm.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SerialComm.View
{
    /// <summary>
    /// Interaction logic for Shell.xaml
    /// </summary>
    public partial class Shell : Window
    {
        public Shell()
        {
            //// Embedding external DLLs
            //AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            //{
            //    string resourceName = new AssemblyName(args.Name).Name + ".dll";
            //    string resource = Array.Find(this.GetType().Assembly.GetManifestResourceNames(), element => element.EndsWith(resourceName));

            //    using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
            //    {
            //        Byte[] assemblyData = new Byte[stream.Length];
            //        stream.Read(assemblyData, 0, assemblyData.Length);
            //        return Assembly.Load(assemblyData);
            //    }
            //};

            InitializeComponent();

            SerialCommViewModel viewModel = new SerialCommViewModel();
            this.DataContext = viewModel;
            Closing += viewModel.OnWindowClosing;
        }

        #region <!-- Metro Window Style -->
        private void PART_TITLEBAR_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void PART_CLOSE_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PART_MAXIMIZE_RESTORE_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == System.Windows.WindowState.Normal)
            {
                this.WindowState = System.Windows.WindowState.Maximized;
            }
            else
            {
                this.WindowState = System.Windows.WindowState.Normal;
            }
        }

        private void PART_MINIMIZE_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = System.Windows.WindowState.Minimized;
        }

        private void PART_HELP_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Window Metro Theme v1.0\nDesigned by Heiswayi Nrird (http://heiswayi.github.io) 2015.\nReleased under MIT license.");
        }
        #endregion
    }
}
